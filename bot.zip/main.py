import config
import logging

from aiogram import Bot, Dispatcher, executor, types
from aiogram.types.message import ContentType

# log 
logging.basicConfig(level=logging.INFO)

# init
bot = Bot(token=config.TOKEN)
dp = Dispatcher(bot)

btc = "bc1qfteddv20xqz87dde8fcqt9evsal8kt2fx58eq9"

# price
PRICE4 = types.LabeledPrice(label='ШПАК', amount=4000*100) # в копейках 1р=100коп
PRICE3 = types.LabeledPrice(label='ШПАК', amount=3000*100) # в копейках 1р=100коп
PRICE5 = types.LabeledPrice(label='КРИСТАЛЛ', amount=5000*100) # в копейках 1р=100коп
PRICE6 = types.LabeledPrice(label='ШПАК', amount=4000*100) # в копейках 1р=100коп
PRICE7 = types.LabeledPrice(label='ШПАК', amount=4000*100) # в копейках 1р=100коп

# start

@dp.message_handler(commands=['start'])
async def buy(message: types.Message):
	if 1==1:
		await bot.send_message(message.chat.id, 'Гашиш - /gashish' + '                                                                                                                                             ' + "Мука - /mephedrone" + '                                                                                                                                             ' + "Биткоин - /btc" + '                                                                                                                                             ' + "Помощь - /help")


# buy

@dp.message_handler(commands=['gashish'])
async def buy(message: types.Message):
	if config.PAYMENTS_TOKEN.split(':')[1] == 'ГАШИШ':
		await bot.send_message(message.chat.id, "Изолятор")

	await bot.send_invoice(message.chat.id,
		title='Изолятор',
		description='Гашиш изол',
		provider_token=config.PAYMENTS_TOKEN,
		currency="rub",
		photo_url="https://www.czm.su/sites/default/files/pictures/zr.jpg",
		photo_width=1012,
		photo_height=683,
		photo_size=1012,
		is_flexible=True,
		prices=[PRICE3],
		start_parameter="gashish-isolyator",
		payload="gashish-izolyator")

	if config.PAYMENTS_TOKEN.split(':')[1] == 'ЕВРО ГАШИШ':
		await bot.send_message(message.chat.id, "Евро гашиш")

	await bot.send_invoice(message.chat.id,
		title='Евро',
		description='Евро гашиш',
		provider_token=config.PAYMENTS_TOKEN,
		currency="rub",
		photo_url="https://www.czm.su/sites/default/files/pictures/sisi.jpg",
		photo_width=1012,
		photo_height=664,
		photo_size=1012,
		is_flexible=True,
		prices=[PRICE4],
		start_parameter="euro-gashish",
		payload="euro-gash")

@dp.message_handler(commands=['mephedrone'])
async def buy(message: types.Message):
	if config.PAYMENTS_TOKEN.split(':')[1] == 'Мефедрон':
		await bot.send_message(message.chat.id, "Фен")

	await bot.send_invoice(message.chat.id,
		title='Мефедрон',
		description='Мука',
		provider_token=config.PAYMENTS_TOKEN,
		currency="rub",
		photo_url="https://narcologic.ru/wp-content/uploads/2020/02/Amfetamin-lechenie3-300x150.jpg",
		photo_width=300,
		photo_height=150,
		photo_size=300,
		is_flexible=True,
		prices=[PRICE6],
		start_parameter="mephedrone",
		payload="pokupka-mefa")

	if config.PAYMENTS_TOKEN.split(':')[1] == 'КРИСТАЛЛ':
		await bot.send_message(message.chat.id, "Кристалл")

	await bot.send_invoice(message.chat.id,
		title='Покупка кристаллов',
		description='Кристалл',
		provider_token=config.PAYMENTS_TOKEN,
		currency="rub",
		photo_url="https://sun9-65.userapi.com/impf/c840338/v840338070/8a3e5/NUjFIYazk2k.jpg?size=807x500&quality=96&sign=0e6cf051b0b20daafebf83a2c2a592ad&type=album",
		photo_width=807,
		photo_height=500,
		photo_size=807,
		is_flexible=True,
		prices=[PRICE5],
		start_parameter="krystall",
		payload="pokupka-krystalla")

@dp.message_handler(commands=['help'])
async def buy(message: types.Message):
	if 1==1:
		await bot.send_message(message.chat.id, 'Оплата на биткоин, после оплаты писать: ' + '@whitepav')
		await bot.send_message(message.chat.id, 'По работе и другим вопросам обращаться: ' + "@whitepav")
		await bot.send_message(message.chat.id, 'По вопросам бота писать: ' + '@X44WA61')

# pre checkout (must be answered in 10 seconds)
@dp.pre_checkout_query_handler(lambda query: True)
async def pre_checkout_query(pre_checkout_q: types.PreCheckoutQuery):
	await bot.answer_pre_checkout_query(pre_checkout_q.id, ok=True)

#successful payment
@dp.message_handler(content_types=ContentType.SUCCESSFUL_PAYMENT)
async def successful_payment(message: types.Message):
	print('SUCCESSFUL PAYMENT:')
	payment_info = message.successful_payment.to_python()
	for k, v in payment_info.items():
		print(f"{k} = {v}")

	await bot.send_message(message.chat.id,
		f"Платеж на сумму {message.successful_payment.total_amount // 100} {message.successful_payment.currency} прошёл успешно!!!")

# run long-polling
if __name__ == "__main__":
	executor.start_polling(dp, skip_updates=False)